#define Package(name, body)\
void name (void){\
    body\
    imp = fun[*(int*)(ptr += sizeof(int))];\
}
